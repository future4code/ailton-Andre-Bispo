// const texto = "        Quem é você?"
// const textoMinusculo = texto.toLowerCase()

// console.log(texto)
// console.log(textoMinusculo)

// alert(textoMinusculo)

// console.log(texto.trim())

// let nome1 = "Britney        Spears"
// let nome2 = "     Adele"
// let nome3 = prompt("Qual é o seu nome?")
// //             //parametro
// function formatar(nome) {
//     // nome = nome.toLowerCase()
//     // nome = nome.trim()
//     // nome = nome.replaceAll(" ", "")
//     // nome = nome.toLowerCase().trim().replaceAll(" ", "")
//     nome = nome.toLowerCase().trim().replaceAll("i", "a")
//     return nome
// }

//  //argumento

// // console.log(formatar(nome1))
// // console.log(formatar(nome2))
// console.log(formatar(nome3))

// function imprimeNome(nome) {
//     console.log(`Olá, ${nome} `)
// }

// let nome1 = prompt("Qual seu nome?")
// imprimeNome(nome1)
// imprimeNome("André Luiz")
// imprimeNome("Savio Ayres")


//PARTE 2 DA AULA

// const a = 1

// function imprimeVariavel() {
//     const b = 2
//     console.log("console no escopo local", a, b)
// }

// imprimeVariavel()

// console.log("console no escopo global:", a, b)

// let numero1 = 15
// let numero2 = 20

// function soma(num1, num2) {
//   let soma = num1 + num2
//     return soma
// }

// function multiplica(num1, num2) {
//     let multiplicacao = num1 * num2
//       return multiplicacao
// }

// // const resultado = soma(7, 4)

// console.log(soma(numero1, numero2))
// console.log(multiplica(numero1, numero2))

// function soma(num1, num2) {
//     return num1 + num2
// }

// const soma = function(num1, num2) {
//     return num1 + num2
// }

// const soma = (num1, num2) => {
//     return num1 + num2
// }

// const soma = (num1, num2) => num1 + num2

// console.log(soma(1, 2))

// const formataNome = nome => {
//     return nome.toLowerCase()
// }

// const formataNome = nome => nome.toLowerCase().trim()


// Criar uma funçao que receba 2 números. Retorne a soma e a multiplicação desses numeros. 

// function(a, b) {

// }

const a = 10
const b = 5

// function soma(a, b) {
//     let soma = a + b
//     return soma
// }

// const mult = (num1, num2) => num1 * num2

// const resultado = soma(a, b)

// console.log(resultado)
// console.log(mult(a, b))

// const somaEMultiplica = (num1, num2) => {
//     const soma = num1 + num2
//     const mult = num1 * num2
//     return [soma, mult]
// }

// console.log(somaEMultiplica(a, b))